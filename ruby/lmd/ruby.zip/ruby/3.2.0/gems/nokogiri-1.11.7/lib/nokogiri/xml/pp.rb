# frozen_string_literal: true
require 'nokogiri/xml/pp/node'
require 'nokogiri/xml/pp/character_data'
