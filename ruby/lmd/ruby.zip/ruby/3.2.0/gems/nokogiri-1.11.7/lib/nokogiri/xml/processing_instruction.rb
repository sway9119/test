# frozen_string_literal: true
module Nokogiri
  module XML
    class ProcessingInstruction < Node
      def initialize document, name, content
      end
    end
  end
end
