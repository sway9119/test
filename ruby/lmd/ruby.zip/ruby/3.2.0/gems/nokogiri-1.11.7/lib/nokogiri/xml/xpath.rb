# frozen_string_literal: true
require 'nokogiri/xml/xpath/syntax_error'

module Nokogiri
  module XML
    module XPath
    end
  end
end
