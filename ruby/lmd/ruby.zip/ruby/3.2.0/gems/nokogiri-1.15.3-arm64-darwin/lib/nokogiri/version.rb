# frozen_string_literal: true

require_relative "version/constant"
require_relative "version/info"
